<template>
    <v-footer class="pa-3 hidden-md-and-down">
        <v-spacer></v-spacer>
        <div>&copy; Designed & Developed By <a style="color:#1565C0;text-decoration: none;" href="https://gdgjalandhar.com" target="_blank">GDG Jalandhar</a></div>
    </v-footer>
</template>

<script>
export default {
}
</script>
